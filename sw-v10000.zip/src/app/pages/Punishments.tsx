import {
  AlertCircle,
  ArrowLeft,
  CalendarDays,
  FileDown,
  Loader2,
  RefreshCcw,
  ShieldAlert,
  ShieldCheck,
  ShieldMinus,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router";

import { Alert, AlertDescription, AlertTitle } from "../components/ui/alert";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { DisciplineStatus } from "../components/shared/DisciplineStatus";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { useData } from "../context/DataContext";
import {
  fetchGuildWeeklyPunishments,
  runGuildWeeklyPunishmentEvaluation,
  type GuildWeeklyPunishmentDto,
} from "../lib/guildImport";

const roleLabelMap: Record<string, string> = {
  leader: "L\u00edder",
  "vice-leader": "Vice-l\u00edder",
  senior: "S\u00eanior",
  member: "Membro",
};

const eventLabelMap: Record<string, string> = {
  guildWar: "GW",
  siege: "Siege",
  guildWarDefenseSetup: "Setup GW",
  siegeDefenseSetup: "Setup Siege",
  guildWarDefenseCompliance: "Alerta GW",
  siegeDefenseCompliance: "Alerta Siege",
  labyrinth: "Labirinto",
  subjugation: "Subjuga\u00e7\u00e3o",
};

const formatRole = (role?: string) => roleLabelMap[role ?? "member"] ?? "Membro";

const formatDateTime = (value?: string) =>
  value
    ? new Date(value).toLocaleString("pt-BR", {
        timeZone: "America/Sao_Paulo",
      })
    : "N\u00e3o informado";

const formatWeekLabel = (punishment: GuildWeeklyPunishmentDto) =>
  `${new Date(punishment.weekStart).toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
  })} a ${new Date(punishment.weekEnd).toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
  })}`;

const escapeHtml = (value: string) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");

const sanitizeFileName = (value: string) =>
  value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[<>:"/\\|?*]+/g, "-")
    .replace(/\s+/g, "_")
    .replace(/-+/g, "-")
    .replace(/_+/g, "_")
    .replace(/^[-_.]+|[-_.]+$/g, "");

export default function Punishments() {
  const { userData, isAdmin, accessToken } = useData();
  const [punishments, setPunishments] = useState<GuildWeeklyPunishmentDto[]>([]);
  const [selectedWeekKey, setSelectedWeekKey] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const loadPunishments = async (weekKey?: string) => {
    if (!accessToken) {
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const next = await fetchGuildWeeklyPunishments(accessToken, weekKey);
      setPunishments(next);
      if (!selectedWeekKey && next[0]?.weekKey) {
        setSelectedWeekKey(next[0].weekKey);
      }
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Falha ao carregar as puni\u00e7\u00f5es.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadPunishments();
  }, [accessToken]);

  useEffect(() => {
    if (!selectedWeekKey) {
      return;
    }

    void loadPunishments(selectedWeekKey);
  }, [selectedWeekKey]);

  const availableWeekKeys = useMemo(
    () => [...new Set(punishments.map((punishment) => punishment.weekKey))],
    [punishments],
  );

  const visiblePunishments = useMemo(
    () =>
      selectedWeekKey
        ? punishments.filter((punishment) => punishment.weekKey === selectedWeekKey)
        : punishments,
    [punishments, selectedWeekKey],
  );

  const summary = useMemo(() => {
    return visiblePunishments.reduce(
      (accumulator, punishment) => {
        accumulator.total += 1;
        if (punishment.punishmentApplied) {
          accumulator.punished += 1;
        } else if (punishment.cooldownActive) {
          accumulator.cooldown += 1;
        } else {
          accumulator.clear += 1;
        }
        if (punishment.markedForRemoval) {
          accumulator.markedForRemoval += 1;
        }
        return accumulator;
      },
      { total: 0, punished: 0, cooldown: 0, clear: 0, markedForRemoval: 0 },
    );
  }, [visiblePunishments]);

  const punishedThisWeek = useMemo(
    () => visiblePunishments.filter((punishment) => punishment.punishmentApplied),
    [visiblePunishments],
  );

  const handleRunEvaluation = async () => {
    if (!accessToken) {
      return;
    }

    setIsRunning(true);
    setError(null);
    setMessage(null);

    try {
      const run = await runGuildWeeklyPunishmentEvaluation(accessToken);
      setSelectedWeekKey(run.weekKey);
      await loadPunishments(run.weekKey);
      setMessage(
        run.skipped
          ? `Avalia\u00e7\u00e3o semanal verificada: ${run.reason}`
          : `Avalia\u00e7\u00e3o semanal conclu\u00edda para ${run.weekKey}. ${run.saved} registro(s) persistido(s).`,
      );
    } catch (runError) {
      setError(
        runError instanceof Error
          ? runError.message
          : "Falha ao executar a avalia\u00e7\u00e3o semanal de puni\u00e7\u00f5es.",
      );
    } finally {
      setIsRunning(false);
    }
  };

  const handleExportPdf = () => {
    if (punishedThisWeek.length === 0) {
      setError("N\u00e3o h\u00e1 membros suspensos na semana selecionada para exportar.");
      return;
    }

    const weekLabel = formatWeekLabel(punishedThisWeek[0]);
    const fileTitle = sanitizeFileName(`CD9_lista_suspensos_semana_${punishedThisWeek[0].weekKey}`);
    const rows = punishedThisWeek
      .map((punishment) => {
        const punishedEvents = punishment.punishedEventKeys.length
          ? punishment.punishedEventKeys
              .map((eventKey) => eventLabelMap[eventKey] ?? eventKey)
              .join(" • ")
          : "Nenhum";
        const details = punishment.events
          .filter((event) => event.punishmentApplied)
          .map(
            (event) =>
              `
                <tr>
                  <td>${escapeHtml(event.label)}</td>
                  <td>${event.completed}/${event.expected}</td>
                  <td>${escapeHtml(event.reason)}</td>
                </tr>
              `,
          )
          .join("");

        return `
          <section class="card">
            <div class="card-header">
              <div>
                <h2>${escapeHtml(punishment.memberName)}</h2>
                <p class="muted">Suspenso na semana ${escapeHtml(weekLabel)}</p>
              </div>
              <div class="pill">${escapeHtml(formatRole(punishment.role))}</div>
            </div>

            <div class="facts">
              <div class="fact">
                <span class="fact-label">Conte?dos</span>
                <span class="fact-value">${escapeHtml(punishedEvents)}</span>
              </div>
              <div class="fact">
                <span class="fact-label">Avaliado em</span>
                <span class="fact-value">${escapeHtml(formatDateTime(punishment.evaluatedAt))}</span>
              </div>
              <div class="fact">
                <span class="fact-label">Pr?xima elegibilidade</span>
                <span class="fact-value">${escapeHtml(
                  punishment.nextEligiblePenaltyAt
                    ? formatDateTime(punishment.nextEligiblePenaltyAt)
                    : "Sem bloqueio de carência",
                )}</span>
              </div>
            </div>

            <div class="summary-box">
              <div class="summary-title">Resumo</div>
              <p>${escapeHtml(punishment.reasonSummary)}</p>
              ${
                punishment.removalReasonSummary
                  ? `<p class="removal"><strong>Remoção:</strong> ${escapeHtml(punishment.removalReasonSummary)}</p>`
                  : ""
              }
            </div>

            <table>
              <thead>
                <tr>
                  <th>Evento</th>
                  <th>Status</th>
                  <th>Motivo</th>
                </tr>
              </thead>
              <tbody>${details}</tbody>
            </table>
          </section>
        `;
      })
      .join("");

    const printableHtml = `
      <!doctype html>
      <html lang="pt-BR">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=1024, initial-scale=1" />
          <title>${escapeHtml(fileTitle)}</title>
          <style>
            @page { size: A4; margin: 14mm; }
            * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            html, body { width: 210mm; min-width: 210mm; margin: 0; padding: 0; background: #ffffff; }
            body { font-family: Arial, sans-serif; color: #111827; }
            .page { width: 182mm; margin: 0 auto; }
            h1 { font-size: 24px; margin: 0 0 8px; color: #0f172a; }
            .subtitle { color: #334155; margin: 0 0 20px; font-weight: 600; }
            .card { border: 1px solid #94a3b8; border-radius: 12px; padding: 16px; margin-bottom: 16px; break-inside: avoid; background: #ffffff; }
            .card-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; margin-bottom: 14px; }
            .pill { border: 1px solid #93c5fd; border-radius: 999px; padding: 6px 10px; font-size: 12px; font-weight: 700; color: #1d4ed8; }
            .facts { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; margin-bottom: 14px; }
            .fact { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; background: #f8fafc; }
            .fact-label { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; color: #64748b; margin-bottom: 4px; }
            .fact-value { display: block; font-size: 13px; font-weight: 600; color: #0f172a; }
            .summary-box { border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px; background: #f8fafc; margin-bottom: 14px; }
            .summary-title { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #64748b; margin-bottom: 6px; }
            .muted { color: #64748b; margin: 2px 0 0; font-size: 13px; }
            .removal { margin-top: 8px; color: #7c2d12; }
            h2 { font-size: 18px; margin: 0; color: #020617; }
            p { margin: 4px 0; line-height: 1.4; color: #1e293b; }
            strong { color: #020617; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border-top: 1px solid #e2e8f0; padding: 10px 8px; text-align: left; vertical-align: top; font-size: 13px; color: #1e293b; }
            th { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: #64748b; background: #f8fafc; }
            td:nth-child(2) { white-space: nowrap; font-weight: 700; color: #0f172a; width: 92px; }
            td:nth-child(1) { width: 150px; font-weight: 700; color: #0f172a; }
            @media print {
              html, body { width: auto; min-width: 0; }
              .page { width: auto; margin: 0; }
            }
          </style>
        </head>
        <body>
          <main class="page">
            <h1>Lista de suspensos da semana</h1>
            <p class="subtitle">Semana ${escapeHtml(weekLabel)} • ${punishedThisWeek.length} membro(s)</p>
            ${rows}
          </main>
        </body>
      </html>
    `;

    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.right = "0";
    iframe.style.bottom = "0";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "0";
    iframe.setAttribute("aria-hidden", "true");
    document.body.appendChild(iframe);

    const iframeDocument = iframe.contentWindow?.document;
    if (!iframeDocument || !iframe.contentWindow) {
      iframe.remove();
      setError("Não foi possível preparar a impressão do PDF.");
      return;
    }

    iframeDocument.open();
    iframeDocument.write(printableHtml);
    iframeDocument.close();

    const cleanup = () => {
      window.setTimeout(() => iframe.remove(), 1000);
    };

    const printOnce = () => {
      const frameWindow = iframe.contentWindow;
      if (!frameWindow) {
        cleanup();
        return;
      }

      frameWindow.onafterprint = cleanup;
      frameWindow.focus();
      frameWindow.print();
    };

    iframe.onload = printOnce;
  };

  if (!userData || !isAdmin()) {
    return (
      <div className="clandestino-shell flex items-center justify-center p-4">
        <Card className="border-2 border-red-500/30 bg-slate-900/80 backdrop-blur-xl">
          <CardHeader>
            <CardTitle className="text-red-400">Acesso negado</CardTitle>
            <CardDescription className="text-slate-300">
              Apenas líderes e vice-líderes podem acessar esta área.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="clandestino-shell p-4 sm:p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <Link to="/admin">
            <Button variant="ghost" className="text-slate-300 hover:bg-slate-800 hover:text-white">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar ao admin
            </Button>
          </Link>

          <div className="clandestino-toolbar">
            <Button
              type="button"
              onClick={() => void handleRunEvaluation()}
              disabled={isRunning || !accessToken}
              className="clandestino-action-button border-red-500/40 bg-gradient-to-b from-red-900/95 to-rose-950/95 !text-red-50 hover:border-red-400/70 hover:from-red-800 hover:to-rose-900"
            >
              {isRunning ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Avaliando
                </>
              ) : (
                <>
                  <ShieldAlert className="mr-2 h-4 w-4" />
                  Rodar avaliação semanal
                </>
              )}
            </Button>

            <Button
              type="button"
              onClick={() => void loadPunishments(selectedWeekKey)}
              disabled={isLoading || !accessToken}
              className="clandestino-action-button clandestino-action-button--refresh !text-cyan-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Atualizando
                </>
              ) : (
                <>
                  <RefreshCcw className="mr-2 h-4 w-4" />
                  Atualizar punições
                </>
              )}
            </Button>

            <Button
              type="button"
              onClick={handleExportPdf}
              disabled={punishedThisWeek.length === 0}
              className="clandestino-action-button border-amber-500/40 bg-gradient-to-b from-amber-900/95 to-orange-950/95 !text-amber-50 hover:border-amber-400/70 hover:from-amber-800 hover:to-orange-900"
            >
              <FileDown className="mr-2 h-4 w-4" />
              Exportar em PDF
            </Button>
          </div>
        </div>

        <Card className="border-2 border-red-500/30 bg-slate-900/60 backdrop-blur-sm">
          <CardHeader>
            <div className="clandestino-page-header">
              <div className="clandestino-page-header__eyebrow">Disciplina semanal</div>
              <CardTitle className="clandestino-page-header__title text-white">
                Puni\u00e7\u00f5es e car\u00eancia
              </CardTitle>
              <CardDescription className="clandestino-page-header__description text-slate-300">
                Aqui a lideran\u00e7a v\u00ea quem ficou de castigo, quem est\u00e1 em car\u00eancia de 15 dias e qual conte\u00fado causou a puni\u00e7\u00e3o. A avalia\u00e7\u00e3o usa a semana de domingo a s\u00e1bado e respeita a regra de n\u00e3o punir de novo na semana seguinte.
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid gap-3 md:grid-cols-5">
              <div className="rounded-xl border border-slate-700/60 bg-slate-800/40 p-4">
                <p className="text-xs text-slate-400">Membros avaliados</p>
                <p className="text-lg font-semibold text-white">{summary.total}</p>
              </div>
              <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4">
                <p className="text-xs text-red-200">Suspensos</p>
                <p className="text-lg font-semibold text-white">{summary.punished}</p>
              </div>
              <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4">
                <p className="text-xs text-amber-200">Ainda suspensos</p>
                <p className="text-lg font-semibold text-white">{summary.cooldown}</p>
              </div>
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4">
                <p className="text-xs text-emerald-200">Sem puni\u00e7\u00e3o</p>
                <p className="text-lg font-semibold text-white">{summary.clear}</p>
              </div>
              <div className="rounded-xl border border-fuchsia-500/30 bg-fuchsia-500/10 p-4">
                <p className="text-xs text-fuchsia-200">Marcados p/ remo\u00e7\u00e3o</p>
                <p className="text-lg font-semibold text-white">{summary.markedForRemoval}</p>
              </div>
            </div>

            <div className="grid gap-3 lg:grid-cols-[18rem_1fr]">
              <div className="space-y-2">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Semana avaliada</p>
                <Select value={selectedWeekKey} onValueChange={setSelectedWeekKey}>
                  <SelectTrigger className="border-slate-700 bg-slate-800/70 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-slate-700 bg-slate-900 text-slate-100">
                    {availableWeekKeys.length === 0 ? (
                      <SelectItem value="">Nenhuma avalia\u00e7\u00e3o dispon\u00edvel</SelectItem>
                    ) : (
                      availableWeekKeys.map((weekKey) => (
                        <SelectItem key={weekKey} value={weekKey}>
                          {weekKey}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-xl border border-slate-700/60 bg-slate-950/20 p-4 text-sm text-slate-300">
                Todo domingo \u00e0s 05:00 de Bras\u00edlia o backend avalia a participa\u00e7\u00e3o da semana fechada.
                A partir de segunda \u00e0s 12:00 de Bras\u00edlia ele tamb\u00e9m avalia setup de defesa,
                exigindo 5 defesas de GW e ao menos 3 de Siege. Se a pessoa entrou em castigo,
                a pr\u00f3xima puni\u00e7\u00e3o s\u00f3 volta a ser eleg\u00edvel 15 dias depois.
              </div>
            </div>

            {error && (
              <Alert variant="destructive" className="border-red-500/30 bg-red-500/10">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Avalia\u00e7\u00e3o conclu\u00edda</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {message && (
              <Alert className="border-emerald-500/30 bg-emerald-500/10 text-emerald-50">
                <ShieldCheck className="h-4 w-4 text-emerald-300" />
                <AlertTitle>Avaliação concluída</AlertTitle>
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-3">
              {visiblePunishments.length === 0 ? (
                <Card className="border border-slate-700/60 bg-slate-900/50">
                  <CardContent className="pt-6 text-center text-slate-400">
                    Nenhuma puni\u00e7\u00e3o semanal foi registrada ainda. Rode a avalia\u00e7\u00e3o manual ou aguarde as janelas autom\u00e1ticas de domingo \u00e0s 05:00 e segunda \u00e0s 12:00.
                  </CardContent>
                </Card>
              ) : (
                visiblePunishments.map((punishment) => (
                  <Card
                    key={`${punishment.weekKey}-${punishment.wizardId}`}
                    className="border border-slate-700/60 bg-slate-900/50"
                  >
                    <CardContent className="space-y-4 pt-6">
                      <div className="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="text-base font-semibold text-white">{punishment.memberName}</p>
                            <Badge className="clandestino-badge border-sky-500/30 bg-sky-500/10 text-sky-200">
                              {formatRole(punishment.role)}
                            </Badge>
                            <DisciplineStatus
                              punishment={punishment}
                              labels={{
                                punished: "Suspenso",
                                cooldown: "Suspenso",
                                clear: "Sem punição",
                              }}
                            />
                            {punishment.markedForRemoval ? (
                              <Badge className="border-fuchsia-500/30 bg-fuchsia-500/10 text-fuchsia-100">
                                Marcado para remo\u00e7\u00e3o</Badge>
                            ) : null}
                          </div>
                          <p className="text-sm text-slate-400">
                            Semana {formatWeekLabel(punishment)} • avaliado em {formatDateTime(punishment.evaluatedAt)}
                          </p>
                          <p className="text-sm text-slate-300">{punishment.reasonSummary}</p>
                          {punishment.removalReasonSummary ? (
                            <p className="text-sm text-fuchsia-200">{punishment.removalReasonSummary}</p>
                          ) : null}
                        </div>

                        <div className="rounded-xl border border-slate-700/60 bg-slate-950/30 p-4 text-sm text-slate-300 xl:min-w-72">
                          <div className="flex items-center gap-2 text-slate-200">
                            <CalendarDays className="h-4 w-4 text-cyan-300" />
                            <span className="font-medium">Próxima elegibilidade</span>
                          </div>
                          <p className="mt-2 text-white">
                            {punishment.nextEligiblePenaltyAt
                              ? formatDateTime(punishment.nextEligiblePenaltyAt)
                              : "Sem bloqueio de carência"}
                          </p>
                          <p className="mt-2 text-xs text-slate-500">
                            Conteúdos punidos:{" "}
                            {punishment.punishedEventKeys.length > 0
                              ? punishment.punishedEventKeys
                                  .map((eventKey) => eventLabelMap[eventKey] ?? eventKey)
                                  .join(" • ")
                              : "nenhum"}
                          </p>
                        </div>
                      </div>

                      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                        {punishment.events.map((event) => (
                          <div
                            key={`${punishment.wizardId}-${event.eventKey}`}
                            className="rounded-xl border border-slate-700/60 bg-slate-950/30 p-4"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm font-semibold text-white">{event.label}</p>
                              {event.punishmentApplied ? (
                                <ShieldAlert className="h-4 w-4 text-red-300" />
                              ) : event.required ? (
                                <ShieldCheck className="h-4 w-4 text-emerald-300" />
                              ) : (
                                <ShieldMinus className="h-4 w-4 text-slate-400" />
                              )}
                            </div>
                            <p className="mt-2 text-sm text-slate-300">
                              {event.completed}/{event.expected}
                            </p>
                            <p className="mt-2 text-xs leading-5 text-slate-500">{event.reason}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
